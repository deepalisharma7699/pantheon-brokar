import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-offer',
  templateUrl: './sales-offer.component.html',
  styleUrls: ['./sales-offer.component.css']
})
export class SalesOfferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
