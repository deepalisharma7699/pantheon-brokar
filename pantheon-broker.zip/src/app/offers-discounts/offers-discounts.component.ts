import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offers-discounts',
  templateUrl: './offers-discounts.component.html',
  styleUrls: ['./offers-discounts.component.css']
})
export class OffersDiscountsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
