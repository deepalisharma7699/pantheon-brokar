import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marketing-collateral',
  templateUrl: './marketing-collateral.component.html',
  styleUrls: ['./marketing-collateral.component.css']
})
export class MarketingCollateralComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
