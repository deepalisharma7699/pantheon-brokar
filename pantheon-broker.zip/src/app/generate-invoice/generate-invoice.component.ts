import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generate-invoice',
  templateUrl: './generate-invoice.component.html',
  styleUrls: ['./generate-invoice.component.css']
})
export class GenerateInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
