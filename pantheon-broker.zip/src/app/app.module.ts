import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ToastrModule } from 'ngx-toastr';

import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';

import { AppComponent } from './app.component';

import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { SalesOfferComponent } from './sales-offer/sales-offer.component';
import { AvailableInventoryComponent } from './available-inventory/available-inventory.component';
import { GenerateInvoiceComponent } from './generate-invoice/generate-invoice.component';
import { MarketingCollateralComponent } from './marketing-collateral/marketing-collateral.component';
import { OffersDiscountsComponent } from './offers-discounts/offers-discounts.component';
import { MyAccountComponent } from './my-account/my-account.component';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    NgbModule,
    ToastrModule.forRoot()
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    SalesOfferComponent,
    AvailableInventoryComponent,
    GenerateInvoiceComponent,
    MarketingCollateralComponent,
    OffersDiscountsComponent,
    MyAccountComponent

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
