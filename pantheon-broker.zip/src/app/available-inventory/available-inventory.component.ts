import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-available-inventory',
  templateUrl: './available-inventory.component.html',
  styleUrls: ['./available-inventory.component.css']
})
export class AvailableInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
